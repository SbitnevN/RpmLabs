﻿namespace $rootnamespace$;

public class $safeitemname$
{
    private DatabaseContext DatabaseContext = DatabaseContext.Instance;

    public IEnumerable<ModelExample> GetAll()
    {
        return DatabaseContext.Entities.AsNoTracking().ToList();
    }
}