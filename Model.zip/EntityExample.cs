﻿namespace $rootnamespace$;

public class $safeitemname$
{
    [Key]
    public Guid Id { get; set; }

    //public Guid OtherEntityId { get; set; }

    //[ForeignKey(nameof(OtherEntityId))]
    //public OtherEntity OtherEntity { get; set; }

    public string Name { get; set; } = string.Empty;
}