﻿namespace $rootnamespace$;

public class $safeitemname$ : ModelBase, IEntityConvertable<$safeitemname$>
{
    private string _testValue = string.Empty;
    public string TestValue
    {
        get { return _testValue; }
        set
        {
            _testValue = value;
            IsChanged = true;
        }
    }

    public void FromEntity($safeitemname$ entity)
    {
        ;
    }

    public $safeitemname$ ToEntity()
    {
        $safeitemname$ entity = new $safeitemname$();
        return entity;
    }

    public override ValidateResult Validate()
    {
        ValidateResult result = new ValidateResult();
        return result;
    }
}