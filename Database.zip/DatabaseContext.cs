﻿namespace $rootnamespace$;

public class DatabaseContext : DbContext
{
    private static DatabaseContext? _instance;
    public static DatabaseContext Instance
    {
        get
        {
            if (_instance is null)
                _instance = new DatabaseContext();

            return _instance;
        }
    }

    // public DbSet<Entity> Entities { get; set; }
    // dotnet ef migrations add InitialCreate --context BlogContext --output-dir Migrations/SqlServerMigrations

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlServer("Server=localhost;Database=Base;Trusted_Connection=True;TrustServerCertificate=True");
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
    }
}
