﻿namespace $rootnamespace$
{
    public interface IValidatable
    {
        public ValidateResult Validate();
    }
}