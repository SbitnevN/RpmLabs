﻿namespace $rootnamespace$
{
    public interface INotifiable
    {
        public bool IsChanged { get; }
        public void ChangeNotify();
        public void Notify(string message);
    }
}