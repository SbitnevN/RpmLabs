﻿namespace $rootnamespace$
{
    public interface ICustomClonable
    {
        public T Clone<T>();
    }
}