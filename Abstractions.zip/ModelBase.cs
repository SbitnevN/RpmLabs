﻿using System.Windows;

namespace $rootnamespace$
{
    public class ModelBase : IValidatable, INotifiable, ICustomClonable
    {
        private const string SuccessfulChanges = "Успешно изменен";

        public bool IsChanged { get; private protected set; }

        public void ChangeNotify()
        {
            if (IsChanged)
                MessageBox.Show(SuccessfulChanges);
            IsChanged = false;
        }

        public T Clone<T>()
        {
            return (T)MemberwiseClone();
        }

        public void Notify(string message)
        {
            MessageBox.Show(message);
        }

        public virtual ValidateResult Validate()
        {
            return default;
        }
    }
}