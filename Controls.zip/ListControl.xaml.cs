﻿using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using Snipets.Model;

namespace $rootnamespace$
{
    public partial class ListControl : UserControl
    {
        private EditorBase? _editor;
        private ModelBase? _emptyModel;

        public event Action<ModelBase?>? OnRemoveItem;
        public event Action<ModelBase?>? OnAddItem;
        public event Action<ModelBase?>? OnChangeItem;

        public ObservableCollection<ModelBase> Items { get; } = new ObservableCollection<ModelBase>();

        public ListControl()
        {
            InitializeComponent();
            DataContext = this;
        }

        private void ChangeButtonClick(object sender, RoutedEventArgs e)
        {
            if (_editor is null)
                return;

            ModelBase? model = GetSelectedItem();
            if (model is null)
                return;

            ModelBase clone = model.Clone<ModelBase>();
           
            _editor.Show(clone, false);

            bool result = (_editor.DialogResult ?? false) && (_editor.Model?.IsChanged ?? false);

            if (result)
                OnChangeItem?.Invoke(_editor?.Model);
        }

        private void RemoveButtonClick(object sender, RoutedEventArgs e)
        {
            ModelBase? model = GetSelectedItem();
            if (model is null)
                return;

            OnRemoveItem?.Invoke(model);
        }

        private void AddButtonClick(object sender, RoutedEventArgs e)
        {
            if (_editor is null)
                return;

            ModelBase? model = _emptyModel?.Clone<ModelBase>();

            _editor.Show(model);

            bool result = _editor.DialogResult ?? false;
            if (result)
                OnAddItem?.Invoke(model);
        }

        public void Load(IEnumerable<ModelBase> models, EditorBase editor, ModelBase emptyModel)
        {
            Items.Clear();
            Data.GenerateDataGrid(models.First());

            foreach (ModelBase model in models)
                Items.Add(model);
            Items.Refresh();

            _editor = editor;
            _emptyModel = emptyModel;
        }

        private ModelBase? GetSelectedItem()
        {
            int index = Data.SelectedIndex;
            if (index == -1)
                return null;

            if (Data.Items[index] is ModelBase)
                return (ModelBase) Data.Items[index];

            return null;
        }
    }
}
