﻿using System.Collections.ObjectModel;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace $rootnamespace$
{
    public partial class SelectorBase : Window
    {
        public ModelBase? SelectedItem { get; set; }

        public ObservableCollection<ModelBase> Items { get; } = new ObservableCollection<ModelBase>();

        public SelectorBase(IEnumerable<ModelBase> items)
        {
            InitializeComponent();
            DataContext = this;

            foreach (ModelBase item in items)
                Items.Add(item);
            Items.Refresh();

            Data.GenerateDataGrid(items.First());
        }

        public void SelectButtonClick(object sender, RoutedEventArgs e)
        {
            int index = Data.SelectedIndex;
            if (index == -1)
                return;

            SelectedItem = (ModelBase)Data.Items[index];
            DialogResult = true;
        }

        public void CancelButtonClick(object sender, RoutedEventArgs e)
        {
            Close();
            DialogResult = false;
        }

        public T? GetSelectedItem<T>() where T : ModelBase
        {
            return (T?)SelectedItem;
        }
    }

    public static class Extensions
    {
        public static void Refresh<T>(this ObservableCollection<T> value)
        {
            CollectionViewSource.GetDefaultView(value).Refresh();
        }

        public static void GenerateDataGrid(this DataGrid dataGrid, object itemTemplate)
        {
            dataGrid.Columns.Clear();

            if (itemTemplate is null)
                return;

            Type type = itemTemplate.GetType();
            PropertyInfo[] properties = type.GetProperties();

            foreach (PropertyInfo property in properties)
            {
                if (BlockedColumns.Contains(type, property.Name))
                    continue;

                dataGrid.Columns.Add(new DataGridTextColumn
                {
                    Header = LocalizedColumns.Get(property.Name),
                    Binding = new Binding(property.Name),
                });
            }
        }
    }

    public static class BlockedColumns
    {
        public static IDictionary<Type, IEnumerable<string>> Columns { get; } = new Dictionary<Type, IEnumerable<string>>() 
        {
            [typeof(ModelExample)] = ["IsChanged", ""],
        };

        public static bool Contains(Type type, string name)
        {
            if (!Columns.ContainsKey(type))
                return false;
            return Columns[type].Contains(name);
        }
    }

    public static class LocalizedColumns
    {
        public static IDictionary<string, string> Columns { get; } = new Dictionary<string, string>()
        {
            ["TestValue"] = "Номер",
        };

        public static string Get(string name)
        {
            if (!Columns.ContainsKey(name))
                return name;
            return Columns[name];
        }
    }
}
