﻿using System.Windows.Controls;
using Snipets.Model;

namespace $rootnamespace$
{
    /// <summary>
    /// Interaction logic for SelectControl.xaml
    /// </summary>
    public partial class SelectControl : UserControl
    {
        private ModelBase? _value;


        public event Action? SelectClicked;

        public string Text { get; set; } = string.Empty;
        public SelectorBase? Selector { get; set; }


        public SelectControl()
        {
            InitializeComponent();

            DataContext = this;
        }

        private void SelectClick(object sender, System.Windows.RoutedEventArgs e)
        {
            SelectClicked?.Invoke();

            if (Selector is null)
                return;

            bool result = Selector.ShowDialog() ?? false;
            if (!result)
                return;

            _value = Selector.SelectedItem;
            Text = _value?.ToString() ?? string.Empty;
        }

        public T? GetValue<T>() where T : ModelBase
        {
            return (T?)_value;
        }  
    }
}
